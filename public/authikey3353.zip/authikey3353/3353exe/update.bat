@ECHO OFF
cd /d "%~dp0"
.\TPMFactoryUpd.exe -update tpm20-emptyplatformauth -firmware .\TPM20_5.63.3144.0_to_TPM20_5.63.3353.0.BIN
PAUSE