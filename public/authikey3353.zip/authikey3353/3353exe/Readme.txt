1. Visit Authikey.com and download the 'authikey3353.zip' file.
2. After downloading, extract the '3353exe' folder to your desktop.
3. Access the BIOS settings and disable 'Trusted Computing.'
4. Boot into Windows 11.
5. Open the '3353exe' folder on your desktop.
6. Right-click on 'update.bat' and select 'Run as administrator.'
7. A pop-up window will appear, showing that the Infineon SLB9665 firmware is being updated.
8. Once the update is successful, close the window.
(If the update doesn't start successfully, ensure 'Trusted Computing' is disabled in the BIOS and that 'update.bat' is being run as an administrator.)
9. Re-enter the BIOS settings, enable 'Trusted Computing,' save the changes, and restart your computer.
10. Verify the TPM status in Windows 11.